#!/bin/bash
#SBATCH -N 1
#SBATCH --gres=gpu:1
#SBATCH --mem=48GB
#SBATCH -t 01:00:00
#SBATCH -J nemo_train
#SBATCH --output=slurm_output_%j.out

module load cuda/12.1
module load python-uv

apptainer exec --nv --bind $PWD:/mnt ../gordon_nemo.sif bash -c "
    cd /mnt &&     uv venv .venv &&     source .venv/bin/activate &&     uv sync &&     python src/dummy_recipe_mwe_gpu_8.py
"
