#!/bin/bash
cd "$(dirname "$0")"
sbatch run_in_slurm.sh
