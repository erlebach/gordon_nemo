#!/bin/bash
set -e
cd "$(dirname "$0")"
apptainer build ../gordon_nemo.sif apptainer.def
