# Gordon NeMo HPC Environment

## Build the Container

```bash
./env/build_image.sh
```

## Submit a Slurm Job

```bash
./jobs/submit_job.sh
```

## Layout

- `env/`: container build files
- `jobs/`: job launcher + template
- `src/`: NeMo experiments or scripts
- `pyproject.toml`: package spec (uses `uv`)
